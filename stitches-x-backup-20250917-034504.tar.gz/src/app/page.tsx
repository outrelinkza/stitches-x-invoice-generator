'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';

// Extend Window interface for auto-save timeout
declare global {
  interface Window {
    autoSaveTimeout?: NodeJS.Timeout;
  }
}
import { useRouter } from 'next/navigation';
import FloatingCalculator from '@/components/FloatingCalculator';
import { generateInvoicePDF, InvoiceData } from '@/utils/pdfGenerator';
import { createOneTimePayment, createSubscription, PRICING_PLANS } from '@/utils/paymentService';
import { useAuth } from '@/contexts/AuthContext';
import { AuthModal } from '@/components/AuthModal';
import { PaymentGateModal } from '@/components/PaymentGateModal';
import { canDownloadPDF, incrementInvoiceCount, markInvoiceAsPaid } from '@/utils/paymentGate';
import { InvoiceService } from '@/utils/invoiceService';
import { showSuccess, showError, showInfo, showLoading, hideNotification } from '@/utils/notifications';
import NavHeader from '@/components/NavHeader';
import LivePreviewWithSettings from '@/components/LivePreviewWithSettings';
import { useUnifiedInvoiceState } from '@/hooks/useUnifiedInvoiceState';

export default function Home() {
  // Unified state management
  const {
    selectedTemplate,
    currentTemplateState,
    currentInvoiceData,
    isFormValid,
    hasUnsavedChanges,
    switchTemplate,
    updateTemplateState,
    toggleElement,
    updateCustomField,
    addCustomField,
    removeCustomField,
    updateInvoiceItem,
    addInvoiceItem,
    removeInvoiceItem,
    calculateTotals,
    resetTemplate,
    saveChanges,
  } = useUnifiedInvoiceState('standard');

  // UI state (not related to invoice data)
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [isGuestMode, setIsGuestMode] = useState(false);
  const { user } = useAuth();
  const router = useRouter();
  const [showResetModal, setShowResetModal] = useState(false);
  const [showCustomizationModal, setShowCustomizationModal] = useState(false);
  const [pricingMode, setPricingMode] = useState<'per-invoice' | 'subscription'>('subscription');
  
  // Payment gate state
  const [showPaymentGate, setShowPaymentGate] = useState(false);
  const [paymentGateStatus, setPaymentGateStatus] = useState({
    isGuest: true,
    remainingFreeInvoices: 1,
  });
  // showCustomBuilder removed - now using unified TemplateManager
  
  // Download limitations
  const [guestInvoiceCount, setGuestInvoiceCount] = useState(0);
  const [showGuestLimitModal, setShowGuestLimitModal] = useState(false);
  const GUEST_INVOICE_LIMIT = 1; // Only 1 free download for guests
  const REGISTERED_INVOICE_LIMIT = 2; // Exactly 2 free downloads for registered users
  
  // Legacy state variables (temporary - will be removed after full migration)
  const [logo, setLogo] = useState<string | null>(null);
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [currentTotal, setCurrentTotal] = useState('0.00');
  const [currency, setCurrency] = useState('USD');
  const [discountRate, setDiscountRate] = useState(0);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [showTotals, setShowTotals] = useState(true);
  const [lineItems, setLineItems] = useState([{ id: 1, description: '', quantity: 1, rate: 0, amount: 0 }]);
  const [invoiceType, setInvoiceType] = useState('product_sales');
  
  // Legacy custom template state (temporary)
  const [customTemplate, setCustomTemplate] = useState({
    name: 'My Custom Template',
    primaryColor: '#7C3AED',
    secondaryColor: '#8B5CF6',
    accentColor: '#A78BFA',
    backgroundColor: '#ffffff',
    textColor: '#1a1a2e',
    borderStyle: 'solid',
    cornerRadius: 'medium',
    fontFamily: 'Helvetica',
    fontSize: '12px',
    fontWeight: '400',
    headerStyle: 'modern',
    layout: 'standard',
    tableStyle: 'bordered',
    spacing: 'comfortable',
    showLogo: true,
    logoPosition: 'left',
    showCompanyInfo: true,
    showClientInfo: true,
    showInvoiceDetails: true,
    showLineItems: true,
    showTotals: true,
    showPaymentTerms: true,
    showAdditionalNotes: true,
    showTermsAndConditions: true,
    showWatermark: false,
    showSignature: false,
    showTerms: false,
    sectionOrder: ['header', 'items', 'totals', 'footer'],
    headerHeight: 'auto',
    footerHeight: 'auto',
    showPageNumbers: false,
    showInvoiceDate: true,
    showDueDate: true,
    showInvoiceNumber: true,
    showClientAddress: true,
    showCompanyAddress: true,
    showTaxBreakdown: false,
    showDiscounts: false,
    showPaymentInfo: false,
    showNotes: false,
    showThankYouMessage: false,
    headerBackground: 'transparent',
    footerBackground: 'transparent',
    accentStyle: 'subtle',
    shadowStyle: 'none',
    showFooter: true
  });
  
  // Legacy functions (temporary)
  const generateInvoiceNumber = useCallback(async () => {
    return `INV-${Date.now()}`;
  }, []);
  
  const addLineItem = useCallback(() => {
    const newId = Math.max(...lineItems.map(item => item.id), 0) + 1;
    setLineItems([...lineItems, { id: newId, description: '', quantity: 1, rate: 0, amount: 0 }]);
  }, [lineItems]);
  
  // Refs for form handling
  const logoInputRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  

  // No redirect - let authenticated users stay on invoice page

  // Handle payment success/cancel messages
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const paymentStatus = urlParams.get('payment');
      const subscriptionStatus = urlParams.get('subscription');
      
      if (paymentStatus === 'success') {
        showSuccess('Payment successful! Your invoice is ready for download.');
        // Clean up URL
        window.history.replaceState({}, '', window.location.pathname);
      } else if (paymentStatus === 'cancelled') {
        showError('Payment was cancelled. You can try again anytime.');
        // Clean up URL
        window.history.replaceState({}, '', window.location.pathname);
      } else if (subscriptionStatus === 'success') {
        showSuccess('Subscription activated! You now have unlimited access.');
        // Clean up URL
        window.history.replaceState({}, '', window.location.pathname);
      } else if (subscriptionStatus === 'cancelled') {
        showError('Subscription was cancelled. You can try again anytime.');
        // Clean up URL
        window.history.replaceState({}, '', window.location.pathname);
      }
    }
  }, []);

  // Load selected template on component mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Load guest invoice count
      const savedGuestCount = localStorage.getItem('guestInvoiceCount');
      if (savedGuestCount) {
        setGuestInvoiceCount(parseInt(savedGuestCount) || 0);
      }

      // Listen for guest mode event from auth modal
      const handleGuestMode = () => {
        setIsGuestMode(true);
      };
      
      window.addEventListener('enableGuestMode', handleGuestMode);
      
      return () => {
        window.removeEventListener('enableGuestMode', handleGuestMode);
      };
      
      // Load custom template if it exists
      const savedCustomTemplate = localStorage.getItem('customTemplate');
      if (savedCustomTemplate) {
        try {
          setCustomTemplate(JSON.parse(savedCustomTemplate as string));
          // If custom template exists, set selected template to custom
          switchTemplate('custom');
        } catch (error) {
          console.error('Failed to parse custom template:', error);
        }
      } else {
        // Only load saved template if no custom template exists
        const savedTemplate = localStorage.getItem('selectedTemplate');
        if (savedTemplate) {
          switchTemplate(savedTemplate as string);
        }
      }
      
      // Add email function to global scope
      (window as any).sendInvoiceEmail = async (clientEmail: string, clientName: string, invoiceNumber: string, total: number, companyName: string) => {
        try {
          const response = await fetch('/api/send-invoice', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              clientEmail,
              clientName,
              invoiceNumber,
              total,
              companyName,
            }),
          });

          const result = await response.json();

          if (response.ok) {
            showSuccess('Invoice sent successfully!');
          } else {
            showError(result.error || 'Failed to send invoice email.');
          }
        } catch (error) {
          console.error('Invoice email error:', error);
          showError('Network error. Please try again.');
        }
      };
    }
  }, []);

  // Get input styles based on selected template
  const getInputStyles = () => {
    switch (selectedTemplate) {
      case 'minimalist-dark':
        return 'border-gray-600/50 bg-gray-800/30 focus:border-gray-400 px-3 py-2 box-border';
      case 'recurring-clients':
        return 'border-blue-400/30 bg-blue-900/20 focus:border-blue-300 px-3 py-2 box-border';
      case 'creative-agency':
        return 'border-pink-400/30 bg-pink-900/20 focus:border-pink-300 px-3 py-2 box-border';
      case 'consulting':
        return 'border-gray-400/30 bg-gray-800/20 focus:border-gray-300 px-3 py-2 box-border';
      case 'custom':
        return 'border-white/20 bg-white/10 focus:border-white/40 px-3 py-2 box-border';
      case 'modern-tech':
        return 'border-cyan-400/30 bg-cyan-900/20 focus:border-cyan-300 px-3 py-2 box-border';
      case 'elegant-luxury':
        return 'border-amber-400/30 bg-amber-900/20 focus:border-amber-300 px-3 py-2 box-border';
      case 'healthcare':
        return 'border-emerald-400/30 bg-emerald-900/20 focus:border-emerald-300 px-3 py-2 box-border';
      case 'legal':
        return 'border-slate-400/30 bg-slate-900/20 focus:border-slate-300 px-3 py-2 box-border';
      case 'restaurant':
        return 'border-orange-400/30 bg-orange-900/20 focus:border-orange-300 px-3 py-2 box-border';
      default:
        return 'border-white/20 bg-white/10 input-focus-glow px-3 py-2 box-border';
    }
  };

  // Helper function to convert hex to rgba
  const hexToRgba = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  // Get custom input styles for custom template
  const getCustomInputStyles = () => {
    if (selectedTemplate === 'custom') {
      console.log('Applying custom template styles:', {
        selectedTemplate,
        fontFamily: customTemplate.fontFamily,
        fontSize: customTemplate.fontSize,
        fontWeight: customTemplate.fontWeight,
        primaryColor: customTemplate.primaryColor
      });
      return {
        borderColor: hexToRgba(customTemplate.primaryColor, 0.3),
        backgroundColor: hexToRgba(customTemplate.primaryColor, 0.1),
        color: customTemplate.textColor,
        fontFamily: customTemplate.fontFamily,
        fontSize: customTemplate.fontSize,
        fontWeight: customTemplate.fontWeight,
      };
    }
    return {};
  };

  // Get template-specific input classes
  const getTemplateInputClasses = () => {
    switch (selectedTemplate) {
      case 'minimalist-dark':
        return 'text-white placeholder-white/60 bg-black/20 border-white/20';
      default:
        // All templates use white text on transparent background (like Standard)
        return 'text-white placeholder-white/60';
    }
  };

  // Get template-specific text colors
  const getTemplateTextColor = () => {
    switch (selectedTemplate) {
      case 'minimalist-dark':
        return 'text-white';
      default:
        // All templates use white text (like Standard)
        return 'text-white';
    }
  };

  // Get template-specific label colors
  const getTemplateLabelColor = () => {
    switch (selectedTemplate) {
      case 'minimalist-dark':
        return 'text-white/80';
      default:
        // All templates use white/80 labels (like Standard)
        return 'text-white/80';
    }
  };

  // Get template-specific features
  const getTemplateFeatures = () => {
    switch (selectedTemplate) {
      case 'recurring-clients':
        return {
          showSubscriptionFields: true,
          defaultPaymentTerms: 'Net 30',
          showRecurringOptions: true
        };
      case 'creative-agency':
        return {
          showProjectFields: true,
          showMoodBoard: true,
          defaultPaymentTerms: '50% upfront, 50% on completion'
        };
      case 'consulting':
        return {
          showHourlyRates: true,
          showConsultationTypes: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'minimalist-dark':
        return {
          showMinimalFields: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'modern-tech':
        return {
          showProjectFields: true,
          showMoodBoard: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'elegant-luxury':
        return {
          showSubscriptionFields: true,
          showRecurringOptions: true,
          defaultPaymentTerms: 'Net 30'
        };
      case 'healthcare':
        return {
          showHealthcareFields: true,
          defaultPaymentTerms: 'Net 30'
        };
      case 'legal':
        return {
          showLegalFields: true,
          defaultPaymentTerms: 'Net 30'
        };
      case 'restaurant':
        return {
          showRestaurantFields: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'business-professional':
        return {
          showBrandingFields: true,
          showLogoOptions: true,
          defaultPaymentTerms: 'Net 30'
        };
      case 'freelancer-creative':
        return {
          showProjectFields: true,
          showPortfolioLink: true,
          showHourlyRates: true,
          defaultPaymentTerms: '50% upfront, 50% on completion'
        };
      case 'modern-gradient':
        return {
          showProjectFields: true,
          showColorCustomization: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'product-invoice':
        return {
          showProductFields: true,
          showSKUFields: true,
          showShippingFields: true,
          defaultPaymentTerms: 'Net 15'
        };
      case 'international-invoice':
        return {
          showInternationalFields: true,
          showVATFields: true,
          showMultiCurrency: true,
          defaultPaymentTerms: 'Net 30'
        };
      case 'receipt-paid':
        return {
          showReceiptFields: true,
          showPaymentConfirmation: true,
          defaultPaymentTerms: 'Paid'
        };
      case 'subscription-invoice':
        return {
          showSubscriptionFields: true,
          showRecurringOptions: true,
          showBillingCycle: true,
          defaultPaymentTerms: 'Monthly'
        };
      default:
        return {
          showStandardFields: true,
          defaultPaymentTerms: 'Net 15'
        };
    }
  };

  // Real Stripe checkout handler
  const handleStripeCheckout = async (plan: string) => {
    try {
      // Check guest limit before processing payment
      if (!checkGuestLimit()) {
        return;
      }
      
      // Show loading notification
      showInfo(`Redirecting to ${plan} checkout...`);
      
      let success = false;
      
      // Get customer email from form or use default
      const customerEmail = (document.querySelector('input[name="companyContact"]') as HTMLInputElement)?.value || undefined;
      
      // Handle different plan types using your actual Stripe Price IDs
      if (plan === 'pro') {
        // Pro subscription
        success = await createSubscription({
          priceId: PRICING_PLANS.pro.priceId,
          customerEmail: customerEmail,
          metadata: { plan: 'pro' },
        });
      } else if (plan === 'basic-per-invoice') {
        // Basic per-invoice payment
        success = await createOneTimePayment(
          PRICING_PLANS.basic.priceId,
          customerEmail
        );
      } else if (plan === 'premium-per-invoice') {
        // Premium per-invoice payment
        success = await createOneTimePayment(
          PRICING_PLANS.premium.priceId,
          customerEmail
        );
      }
      
      // Remove loading message
      hideNotification();
      
      if (!success) {
        throw new Error('Payment processing failed');
      }
      
    } catch (error) {
      console.error('Checkout error:', error);
      
      hideNotification();
      
      // Show error message
      showError('Payment failed. Please try again.');
    }
  };

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogo(URL.createObjectURL(file));
    }
  };

  const handleRemoveLogo = () => {
    setLogo(null);
    if (logoInputRef.current) {
      logoInputRef.current.value = '';
    }
  };

  const handleReset = () => {
    // Reset all state variables
    // setIsFormValid(false); // Not available in hook
    setShowTotals(true);
    setShowResetModal(false);
    // setHasUnsavedChanges(false); // Not available in hook
    setLogo(null);
    setInvoiceNumber('');
    setCurrentTotal('0.00');
    switchTemplate('standard');
    // setShowCustomBuilder removed - now using unified TemplateManager
    setCustomTemplate({
      name: 'My Custom Template',
      primaryColor: '#7C3AED',
      secondaryColor: '#8B5CF6',
      accentColor: '#A78BFA',
      backgroundColor: '#ffffff',
      textColor: '#1a1a2e',
      fontFamily: 'Inter',
      fontSize: '14px',
      fontWeight: '400',
      layout: 'standard',
      headerStyle: 'full-width',
      logoPosition: 'left',
      showLogo: true,
      showCompanyInfo: true,
      showClientInfo: true,
      showInvoiceDetails: true,
      showLineItems: true,
      showTotals: true,
      showPaymentTerms: true,
      showAdditionalNotes: true,
      showTermsAndConditions: true,
      showWatermark: false,
      showSignature: true,
      showTerms: true,
      spacing: 'normal',
      borderStyle: 'none',
      sectionOrder: ['header', 'company', 'client', 'items', 'totals', 'notes', 'footer'],
      headerHeight: 'medium',
      footerHeight: 'medium',
      showPageNumbers: true,
      showInvoiceDate: true,
      showDueDate: true,
      showInvoiceNumber: true,
      showClientAddress: true,
      showCompanyAddress: true,
      showTaxBreakdown: true,
      showDiscounts: true,
      showPaymentInfo: true,
      showNotes: true,
      showThankYouMessage: true,
      tableStyle: 'bordered',
      headerBackground: 'transparent',
      footerBackground: 'transparent',
      accentStyle: 'subtle',
      shadowStyle: 'none',
      cornerRadius: 'medium',
      showFooter: true
    });
    setLineItems([{ id: 1, description: '', quantity: 1, rate: 0, amount: 0 }]);
    
    // Reset logo input
    if (logoInputRef.current) {
      logoInputRef.current.value = '';
    }
    
    // Reset form fields
    const form = document.querySelector('form');
    if (form) {
      form.reset();
    }
    
    // Clear any localStorage custom template
    if (typeof window !== 'undefined') {
      localStorage.removeItem('customTemplate');
    }
  };

  // Handle PDF generation with payment gating
  const handleGeneratePDF = async () => {
    const paymentCheck = canDownloadPDF(user);
    
    if (!paymentCheck.canDownload) {
      // Show payment gate modal
      setPaymentGateStatus({
        isGuest: !user,
        remainingFreeInvoices: paymentCheck.requiresPayment ? 0 : 1,
      });
      setShowPaymentGate(true);
      return;
    }

    // User can download - proceed with PDF generation
    try {
      generateInvoicePDF(currentInvoiceData);
      incrementInvoiceCount(!user);
      showSuccess('Invoice generated successfully!');
    } catch (error) {
      console.error('Error generating invoice:', error);
      showError('Failed to generate invoice. Please try again.');
    }
  };

  // Handle payment success
  const handlePaymentSuccess = () => {
    markInvoiceAsPaid();
    // Now generate the PDF
    generateInvoicePDF(currentInvoiceData);
    showSuccess('Payment successful! Invoice generated.');
  };

  const handleSaveDraft = useCallback(async () => {
    if (typeof window === 'undefined' || !user) return;
    
    try {
      const formData = new FormData(document.querySelector('form') as HTMLFormElement);
      await InvoiceService.saveDraft(formData);
      // setHasUnsavedChanges(false); // Not available in hook
      // Silent save - no popup notification
    } catch (error) {
      console.error('Failed to save draft:', error);
      showError('Failed to save draft. Please check your connection and try again.');
    }
  }, [user]);

  const handleFormChange = useCallback(() => {
    // setHasUnsavedChanges(true); // Not available in hook
    // Update total in real-time
    setCurrentTotal(calculateTotal({}));
    
    // Check if form is valid
    if (formRef.current) {
      const formData = new FormData(formRef.current);
      const companyName = formData.get('companyName') as string;
      const clientName = formData.get('clientName') as string;
      const hasValidData = !!(companyName && clientName && companyName.trim() !== '' && clientName.trim() !== '');
      // setIsFormValid(hasValidData); // Not available in hook
    }
    
    // Auto-save only if there's meaningful content and after a longer delay
    if (formRef.current) {
      const formData = new FormData(formRef.current);
      const hasContent = Array.from(formData.entries()).some(([key, value]) => 
        value && value.toString().trim() !== '' && key !== 'logo'
      );
      
      if (hasContent) {
        // Clear any existing timeout
        if (window.autoSaveTimeout) {
          clearTimeout(window.autoSaveTimeout);
        }
        
        // Set new timeout for 30 seconds (only save if user stops typing)
        window.autoSaveTimeout = setTimeout(() => {
          handleSaveDraft();
        }, 30000);
      }
    }
  }, [handleSaveDraft]);

  const isFieldEmpty = (value: string | null | undefined) => {
    return !value || value.trim() === '';
  };

  // Guest limitation functions
  const incrementGuestInvoiceCount = () => {
    const newCount = guestInvoiceCount + 1;
    setGuestInvoiceCount(newCount);
    localStorage.setItem('guestInvoiceCount', newCount.toString());
    
    // Check if guest has reached limit
    if (newCount >= GUEST_INVOICE_LIMIT && !user) {
      setShowGuestLimitModal(true);
    }
  };

  const checkDownloadLimit = () => {
    if (!user && guestInvoiceCount >= GUEST_INVOICE_LIMIT) {
      setShowGuestLimitModal(true);
      return false;
    }
    if (user) {
      const registeredCount = parseInt(localStorage.getItem('registeredInvoiceCount') || '0');
      if (registeredCount >= REGISTERED_INVOICE_LIMIT) {
        setShowPaymentGate(true);
        return false;
      }
    }
    return true;
  };

  // Smart Invoice Numbering (duplicate removed)

  // Auto-generate invoice number on component mount
  React.useEffect(() => {
    if (typeof window !== 'undefined' && !invoiceNumber) {
      generateInvoiceNumber().then(number => setInvoiceNumber(number));
    }
  }, [user, invoiceNumber, generateInvoiceNumber]);




  // Smart Tax Rate Memory
  const getSuggestedTaxRates = () => {
    // Return common tax rates
    return [8, 10, 15, 20, 25];
  };

  // Get currency symbol based on selected currency
  const getCurrencySymbol = () => {
    const symbols: { [key: string]: string } = {
      'USD': '$',
      'EUR': '€',
      'GBP': '£',
      'CAD': '$',
      'AUD': '$',
      'JPY': '¥',
      'CHF': 'CHF',
      'SEK': 'kr',
      'NOK': 'kr',
      'DKK': 'kr'
    };
    return symbols[currency] || '$';
  };




  const updateTemplatePreference = (templateName: string) => {
    // Template preferences will be stored in database in future
    console.log('Template preference updated:', templateName);
  };

  // Calculate line item total
  const calculateLineTotal = useCallback((quantity: number, rate: number) => {
    return (quantity * rate).toFixed(2);
  }, []);

  // Add new line item (duplicate removed)

  // Remove line item
  const removeLineItem = useCallback((id: number) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter(item => item.id !== id));
    }
  }, [lineItems]);

  // Update line item
  const updateLineItem = useCallback((id: number, field: string, value: string | number) => {
    setLineItems(lineItems.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        if (field === 'quantity' || field === 'rate') {
          updated.amount = updated.quantity * updated.rate;
        }
        return updated;
      }
      return item;
    }));
  }, [lineItems]);

  // Calculate subtotal from all line items
  const calculateSubtotal = useCallback(() => {
    if (typeof window === 'undefined') return 0;
    
    const lineItems = document.querySelectorAll('[data-line-item]');
    let subtotal = 0;
    
    lineItems.forEach((item) => {
      const quantityInput = item.querySelector('input[name="quantity"]') as HTMLInputElement;
      const rateInput = item.querySelector('input[name="rate"]') as HTMLInputElement;
      const quantity = parseFloat(quantityInput?.value) || 0;
      const rate = parseFloat(rateInput?.value) || 0;
      subtotal += quantity * rate;
    });
    
    return subtotal;
  }, []);

  // Update line item total when quantity or rate changes
  const updateLineItemTotal = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const lineItem = event.target.closest('[data-line-item]');
    if (!lineItem) return;
    
    const quantityInput = lineItem.querySelector('input[name="quantity"]') as HTMLInputElement;
    const rateInput = lineItem.querySelector('input[name="rate"]') as HTMLInputElement;
    const totalSpan = lineItem.querySelector('[data-line-total]') as HTMLSpanElement;
    
    const quantity = parseFloat(quantityInput?.value) || 0;
    const rate = parseFloat(rateInput?.value) || 0;
    const total = calculateLineTotal(quantity, rate);
    
    if (totalSpan) {
      totalSpan.textContent = `$${total}`;
    }
    
    // Update subtotal
    updateSubtotal();
  }, [calculateLineTotal]);

  // Update subtotal and total
  const updateSubtotal = useCallback(() => {
    const subtotal = calculateSubtotal();
    const subtotalInput = document.querySelector('input[name="subtotal"]') as HTMLInputElement;
    const taxRateInput = document.querySelector('input[name="taxRate"]') as HTMLInputElement;
    const totalSpan = document.querySelector('[data-total-display]') as HTMLSpanElement;
    
    if (subtotalInput) {
      subtotalInput.value = subtotal.toFixed(2);
    }
    
    // Calculate discount
    const discount = discountAmount > 0 ? discountAmount : (subtotal * discountRate / 100);
    const subtotalAfterDiscount = subtotal - discount;
    
    const taxRate = parseFloat(taxRateInput?.value) || 0;
    const taxAmount = (subtotalAfterDiscount * taxRate) / 100;
    const total = subtotalAfterDiscount + taxAmount;
    
    if (totalSpan) {
      totalSpan.textContent = total.toFixed(2);
    }
    
    setCurrentTotal(total.toFixed(2));
  }, [calculateSubtotal, discountRate, discountAmount]);

  // Calculate total with tax (memoized for performance)
  const calculateTotal = useCallback((invoiceData: Record<string, string | number>) => {
    // Get current form values if no data provided
    if (!invoiceData || Object.keys(invoiceData).length === 0) {
      const subtotalInput = document.querySelector('input[name="subtotal"]') as HTMLInputElement;
      const taxRateInput = document.querySelector('input[name="taxRate"]') as HTMLInputElement;
      const subtotal = parseFloat(subtotalInput?.value) || 0;
      const taxRate = parseFloat(taxRateInput?.value) || 0;
      const taxAmount = (subtotal * taxRate) / 100;
      return (subtotal + taxAmount).toFixed(2);
    }
    
    const subtotal = parseFloat(String(invoiceData.subtotal)) || 0;
    const taxRate = parseFloat(String(invoiceData.taxRate)) || 0;
    const taxAmount = (subtotal * taxRate) / 100;
    return (subtotal + taxAmount).toFixed(2);
  }, []);

  return (
    <div className="relative flex size-full min-h-screen flex-col group/design-root overflow-x-hidden">
      <NavHeader currentPage="/" />
      <div className="layout-container flex h-full grow flex-col">

        {/* Main Content */}
        <main className="flex flex-1 justify-center pt-20 pb-12 px-4 sm:px-6 lg:px-8">
          <div className="w-full max-w-4xl space-y-8">
            <div className="text-center animate-enter" style={{animationDelay: '200ms'}}>
              <h1 className="font-display text-4xl font-bold tracking-tight text-white sm:text-6xl">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-red-200 via-red-300 to-yellow-200 animate-gradient">
                  Create Professional Invoices in Seconds
                </span>
              </h1>
              <p className="mt-6 max-w-xl mx-auto text-lg text-white/80">
                No signup required. Choose a template, customize, and download your PDF instantly.
              </p>
              
              {/* Single Primary CTA */}
              <div className="mt-8 animate-enter" style={{animationDelay: '300ms'}}>
                  <button
                  onClick={() => router.push('/templates')}
                  className="px-8 py-4 bg-white text-gray-900 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all duration-200 shadow-lg"
                  >
                  Start Creating Free Invoice
                  </button>
                <p className="mt-3 text-white/60 text-sm">
                  ✓ 20+ Professional Templates ✓ Instant PDF Download ✓ No Account Required
                </p>
                </div>
              
            </div>

            <form ref={formRef} onChange={handleFormChange} className={`rounded-2xl shadow-lg p-6 space-y-8 animate-enter ${
              selectedTemplate === 'minimalist-dark' ? 'bg-black/40 border border-white/10' :
              'glass-effect'
            }`} style={{animationDelay: '300ms'}}>
              {/* Guest Mode Banner */}
              {isGuestMode && !user && (
                <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-green-500/20 to-blue-500/20 border border-green-400/30">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">G</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Guest Mode Active</h4>
                      <p className="text-white/70 text-sm">
                        Choose your plan • No account needed • Instant access
                        {guestInvoiceCount > 0 && (
                          <span className="ml-2 text-yellow-400">
                            • {guestInvoiceCount}/{GUEST_INVOICE_LIMIT} invoices used
                          </span>
                        )}
                      </p>
                    </div>
                    <button 
                      onClick={() => {
                        setAuthMode('signup');
                        setAuthModalOpen(true);
                      }}
                      className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white text-sm rounded-lg border border-white/20 transition-colors"
                    >
                      Create Account
                    </button>
                  </div>
                </div>
              )}
              

              {/* Legal Template Specific Section */}
              {selectedTemplate === 'legal' && (
                <section className="space-y-6 p-6 bg-white/10 rounded-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-white">Legal Case Details</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Case Number</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Case #2024-001"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Matter Type</span>
                      <select className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60">
                        <option value="litigation">Litigation</option>
                        <option value="corporate">Corporate Law</option>
                        <option value="real-estate">Real Estate</option>
                        <option value="family">Family Law</option>
                        <option value="criminal">Criminal Defense</option>
                        <option value="immigration">Immigration</option>
                        <option value="patent">Patent Law</option>
                        <option value="other">Other</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Court/Jurisdiction</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Superior Court of California"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Billing Period</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="March 1-31, 2024"
                      />
                    </label>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-md font-semibold text-gray-800">Legal Services</h4>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-5"><span className="text-sm font-medium text-white/80">Service Description</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Hours</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Rate ($)</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Total</span></div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <input 
                        type="text" 
                        className="col-span-5 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Legal research and case preparation"
                      />
                      <input 
                        type="number" 
                        className="col-span-2 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="2.5"
                      />
                      <input 
                        type="number" 
                        className="col-span-2 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="350"
                      />
                      <span className="col-span-2 text-sm text-white">$875.00</span>
                    </div>
                    <button type="button" className="text-sm font-medium text-white/80 hover:text-white transition-colors">+ Add Legal Service</button>
                  </div>
                </section>
              )}

              {/* Restaurant Template Specific Section */}
              {selectedTemplate === 'restaurant' && (
                <section className="space-y-6 p-6 bg-white/10 rounded-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-white">Restaurant Order Details</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Table Number</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Table 12"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Server Name</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Sarah Johnson"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Order Time</span>
                      <input 
                        type="time" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Party Size</span>
                      <input 
                        type="number" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="4"
                      />
                    </label>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-md font-semibold text-orange-800">Menu Items</h4>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-5"><span className="text-sm font-medium text-white/80">Item Name</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Qty</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Price</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Total</span></div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <input 
                        type="text" 
                        className="col-span-5 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Grilled Salmon with Rice"
                      />
                      <input 
                        type="number" 
                        className="col-span-2 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="2"
                      />
                      <input 
                        type="number" 
                        className="col-span-2 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="24.99"
                      />
                      <span className="col-span-2 text-sm text-white">$49.98</span>
                    </div>
                    <button type="button" className="text-sm font-medium text-white/80 hover:text-white transition-colors">+ Add Menu Item</button>
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Service Charge (%)</span>
                      <input 
                        type="number" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="18"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Tax Rate (%)</span>
                      <input 
                        type="number" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="8.5"
                      />
                    </label>
                  </div>
                </section>
              )}

              {/* Healthcare Template Specific Section */}
              {selectedTemplate === 'healthcare' && (
                <section className="space-y-6 p-6 bg-white/10 rounded-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-white">Medical Services</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Patient ID</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="PAT-2024-001"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Insurance Provider</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Blue Cross Blue Shield"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Policy Number</span>
                      <input 
                        type="text" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="BC123456789"
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-white/80">Date of Service</span>
                      <input 
                        type="date" 
                        className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60"
                      />
                    </label>
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-md font-semibold text-emerald-800">Medical Procedures</h4>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-4"><span className="text-sm font-medium text-white/80">Procedure Code</span></div>
                      <div className="col-span-4"><span className="text-sm font-medium text-white/80">Description</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Amount</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium text-white/80">Total</span></div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <input 
                        type="text" 
                        className="col-span-4 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="99213"
                      />
                      <input 
                        type="text" 
                        className="col-span-4 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="Office visit, established patient"
                      />
                      <input 
                        type="number" 
                        className="col-span-2 block w-full rounded-md shadow-sm focus:ring-0 text-white placeholder-white/60" 
                        placeholder="150.00"
                      />
                      <span className="col-span-2 text-sm text-white">$150.00</span>
                    </div>
                    <button type="button" className="text-sm font-medium text-white/80 hover:text-white transition-colors">+ Add Procedure</button>
                  </div>
                </section>
              )}

              {/* Template Showcase Section */}
              <div className="space-y-6 animate-enter" style={{animationDelay: '400ms'}}>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-3">Professional Templates</h2>
                  <p className="text-white/70 text-base">Choose from 20+ industry-specific designs</p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {/* Simplified Template Cards */}
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl text-white/80">business</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">Business Professional</h3>
                  </div>
                  
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl text-white/80">gavel</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">Legal Services</h3>
                  </div>
                  
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl text-white/80">palette</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">Creative Agency</h3>
                  </div>
                  
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl text-white/80">restaurant</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">Restaurant</h3>
                  </div>
                  
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="material-symbols-outlined text-3xl text-white/80">medical_services</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">Healthcare</h3>
                  </div>
                  
                  <div 
                    onClick={() => router.push('/templates')}
                    className="bg-white/5 rounded-lg p-4 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                  >
                    <div className="w-full h-16 bg-white/10 rounded mb-3 flex items-center justify-center">
                      <span className="text-white/80 font-medium text-sm">+ More</span>
                    </div>
                    <h3 className="text-white font-medium text-sm">15+ More</h3>
                  </div>
                </div>
                
                <div className="text-center">
                  <button
                    onClick={() => router.push('/templates')}
                    className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg border border-white/20 transition-all text-sm"
                  >
                    View All Templates
                  </button>
                </div>
              </div>

              {/* Feature Highlights Section */}
              <div className="space-y-6 animate-enter" style={{animationDelay: '500ms'}}>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-3">Key Features</h2>
                  <p className="text-white/70 text-base">Everything you need for professional invoicing</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-white/10 rounded flex items-center justify-center flex-shrink-0 mt-1">
                        <svg className="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">20+ Professional Templates</h3>
                        <p className="text-white/60 text-sm">Industry-specific designs for every business type</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-white/10 rounded flex items-center justify-center flex-shrink-0 mt-1">
                        <svg className="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Instant Payment Processing</h3>
                        <p className="text-white/60 text-sm">Accept payments through secure Stripe integration</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-white/10 rounded flex items-center justify-center flex-shrink-0 mt-1">
                        <svg className="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Cross-Platform Compatibility</h3>
                        <p className="text-white/60 text-sm">Create and manage invoices on any device</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-white/10 rounded flex items-center justify-center flex-shrink-0 mt-1">
                        <svg className="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Professional PDF Export</h3>
                        <p className="text-white/60 text-sm">Download high-quality PDF invoices instantly</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* How It Works Section */}
              <div className="space-y-6 animate-enter" style={{animationDelay: '600ms'}}>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-3">Simple 3-Step Process</h2>
                  <p className="text-white/70 text-base">Get started in minutes</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 text-white text-lg font-bold">
                      1
                    </div>
                    <h3 className="text-white font-medium mb-2">Choose Template</h3>
                    <p className="text-white/60 text-sm mb-3">Select from 20+ professional designs</p>
                    <button
                      onClick={() => router.push('/templates')}
                      className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded border border-white/20 transition-all text-xs"
                    >
                      Browse Templates
                    </button>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 text-white text-lg font-bold">
                      2
                    </div>
                    <h3 className="text-white font-medium mb-2">Customize Content</h3>
                    <p className="text-white/60 text-sm mb-3">Add your information and branding</p>
                    <button
                      onClick={() => setIsGuestMode(true)}
                      className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded border border-white/20 transition-all text-xs"
                    >
                      Start Editing
                    </button>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 text-white text-lg font-bold">
                      3
                    </div>
                    <h3 className="text-white font-medium mb-2">Export PDF</h3>
                    <p className="text-white/60 text-sm mb-3">Download and send to clients</p>
                    <button
                      onClick={() => setIsGuestMode(true)}
                      className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded border border-white/20 transition-all text-xs"
                    >
                      Generate PDF
                    </button>
                  </div>
                </div>
              </div>

              {/* Live Preview Section */}
              <div className="space-y-6 animate-enter" style={{animationDelay: '700ms'}}>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-2">Live Preview</h2>
                  <p className="text-white/80">Experience our template system - no registration required</p>
                </div>
              </div>

              {/* Live Preview with Settings */}
              <div className="bg-gray-900 rounded-lg p-4 h-[600px]">
                <LivePreviewWithSettings 
                  templateState={currentTemplateState}
                  updateTemplateState={updateTemplateState}
                />
              </div>
              
              {/* Legacy Template Sections - Keep for fallback */}
              {getTemplateFeatures().showSubscriptionFields && (
                <section className="space-y-6 p-6 bg-blue-900/20 rounded-lg border border-blue-500/20">
                  <h3 className="text-lg font-semibold text-blue-200">Recurring Client Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-blue-200">Subscription Type</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="monthly">Monthly</option>
                        <option value="quarterly">Quarterly</option>
                        <option value="yearly">Yearly</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-blue-200">Next Billing Date</span>
                      <input type="date" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`} />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showProjectFields && (
                <section className="space-y-6 p-6 bg-pink-900/20 rounded-lg border border-pink-500/20">
                  <h3 className="text-lg font-semibold text-pink-200">Creative Project Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-pink-200">Project Type</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="branding">Branding</option>
                        <option value="web-design">Web Design</option>
                        <option value="print-design">Print Design</option>
                        <option value="social-media">Social Media</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-pink-200">Project Timeline</span>
                      <input type="text" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="Timeline" />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showHourlyRates && (
                <section className="space-y-6 p-6 bg-gray-900/20 rounded-lg border border-gray-500/20">
                  <h3 className="text-lg font-semibold text-gray-200">Consulting Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-gray-200">Consultation Type</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="strategy">Strategy Session</option>
                        <option value="implementation">Implementation</option>
                        <option value="review">Review & Analysis</option>
                        <option value="training">Training</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-gray-200">Hourly Rate</span>
                      <input type="number" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="Hours" />
                    </label>
                  </div>
                </section>
              )}

              {/* New Template-Specific Sections */}
              {getTemplateFeatures().showBrandingFields && (
                <section className="space-y-6 p-6 bg-slate-900/20 rounded-lg border border-slate-500/20">
                  <h3 className="text-lg font-semibold text-slate-200">Business Professional Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-slate-200">Company Tagline</span>
                      <input type="text" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="Your company tagline" />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-slate-200">Business Type</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="corporation">Corporation</option>
                        <option value="llc">LLC</option>
                        <option value="partnership">Partnership</option>
                        <option value="sole-proprietorship">Sole Proprietorship</option>
                      </select>
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showPortfolioLink && (
                <section className="space-y-6 p-6 bg-indigo-900/20 rounded-lg border border-indigo-500/20">
                  <h3 className="text-lg font-semibold text-indigo-200">Freelancer Creative Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-indigo-200">Portfolio Website</span>
                      <input type="url" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="https://yourportfolio.com" />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-indigo-200">Social Media</span>
                      <input type="text" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="@yourhandle" />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showColorCustomization && (
                <section className="space-y-6 p-6 bg-pink-900/20 rounded-lg border border-pink-500/20">
                  <h3 className="text-lg font-semibold text-pink-200">Modern Gradient Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-pink-200">Primary Color</span>
                      <input type="color" className={`mt-1 block w-full h-10 rounded-md shadow-sm focus:ring-0 ${getInputStyles()}`} defaultValue="#7C3AED" />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-pink-200">Secondary Color</span>
                      <input type="color" className={`mt-1 block w-full h-10 rounded-md shadow-sm focus:ring-0 ${getInputStyles()}`} defaultValue="#EC4899" />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showProductFields && (
                <section className="space-y-6 p-6 bg-emerald-900/20 rounded-lg border border-emerald-500/20">
                  <h3 className="text-lg font-semibold text-emerald-200">Product Invoice Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-emerald-200">Shipping Address</span>
                      <textarea className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} rows={3} placeholder="Shipping address"></textarea>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-emerald-200">Shipping Method</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="standard">Standard Shipping</option>
                        <option value="express">Express Shipping</option>
                        <option value="overnight">Overnight</option>
                        <option value="pickup">Store Pickup</option>
                      </select>
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showInternationalFields && (
                <section className="space-y-6 p-6 bg-blue-900/20 rounded-lg border border-blue-500/20">
                  <h3 className="text-lg font-semibold text-blue-200">International Invoice Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-blue-200">VAT/GST Number</span>
                      <input type="text" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="VAT123456789" />
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-blue-200">IBAN/SWIFT</span>
                      <input type="text" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} placeholder="GB29 NWBK 6016 1331 9268 19" />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showReceiptFields && (
                <section className="space-y-6 p-6 bg-green-900/20 rounded-lg border border-green-500/20">
                  <h3 className="text-lg font-semibold text-green-200">Receipt Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-green-200">Payment Method</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="cash">Cash</option>
                        <option value="card">Credit/Debit Card</option>
                        <option value="bank-transfer">Bank Transfer</option>
                        <option value="check">Check</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-green-200">Payment Date</span>
                      <input type="date" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getInputStyles()}`} defaultValue={new Date().toISOString().split('T')[0]} />
                    </label>
                  </div>
                </section>
              )}

              {getTemplateFeatures().showBillingCycle && (
                <section className="space-y-6 p-6 bg-violet-900/20 rounded-lg border border-violet-500/20">
                  <h3 className="text-lg font-semibold text-violet-200">Subscription Features</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="text-sm font-medium text-violet-200">Billing Cycle</span>
                      <select className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`}>
                        <option value="monthly">Monthly</option>
                        <option value="quarterly">Quarterly</option>
                        <option value="yearly">Yearly</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="text-sm font-medium text-violet-200">Next Billing Date</span>
                      <input type="date" className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getInputStyles()}`} />
                    </label>
                  </div>
                </section>
              )}

              {/* Invoice Details Section - Hidden when using new template system */}
              <section className="space-y-6" style={{ display: 'none' }}>
                <h3 className="text-lg font-semibold text-white">Invoice Details</h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-4">
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Invoice Number</span>
                    <input 
                      name="invoiceNumber" 
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 input-focus-glow ${getTemplateInputClasses()}" 
                      placeholder="Invoice number" 
                      type="text"
                    />
                  </label>
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Invoice Date</span>
                    <input 
                      name="date" 
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`} 
                      style={getCustomInputStyles()}
                      type="date" 
                      defaultValue={new Date().toISOString().split('T')[0]}
                    />
                  </label>
                <label className="block">
                  <span className="text-sm font-medium ${getTemplateLabelColor()}">Due Date</span>
                  <input 
                    name="dueDate" 
                    className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 text-white ${getInputStyles()}`} 
                    style={getCustomInputStyles()}
                    type="date" 
                    defaultValue={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
                  />
                </label>
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Invoice Type</span>
                    <select 
                      name="invoiceType"
                      className="mt-1 block w-full rounded-md border-white/20 bg-white/10 shadow-sm focus:ring-0 input-focus-glow text-white" 
                      value={invoiceType}
                      onChange={(e) => setInvoiceType(e.target.value)}
                    >
                      <option value="product_sales" className="bg-slate-800 text-white">Product/Sales</option>
                      <option value="freelance_consulting" className="bg-slate-800 text-white">Freelance/Consulting</option>
                      <option value="time_tracking" className="bg-slate-800 text-white">Time-Based Invoice</option>
                      <option value="simple_receipt" className="bg-slate-800 text-white">Simple Receipt</option>
                    </select>
                  </label>
                </div>
                
                {/* Currency and Additional Details Row */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-4">
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Currency</span>
                    <select 
                      name="currency"
                      className="mt-1 block w-full rounded-md border-white/20 bg-white/10 shadow-sm focus:ring-0 input-focus-glow text-white" 
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value)}
                    >
                      <option value="USD" className="bg-slate-800 text-white">$ USD</option>
                      <option value="EUR" className="bg-slate-800 text-white">€ EUR</option>
                      <option value="GBP" className="bg-slate-800 text-white">£ GBP</option>
                      <option value="CAD" className="bg-slate-800 text-white">$ CAD</option>
                      <option value="AUD" className="bg-slate-800 text-white">$ AUD</option>
                      <option value="JPY" className="bg-slate-800 text-white">¥ JPY</option>
                      <option value="CHF" className="bg-slate-800 text-white">CHF</option>
                      <option value="SEK" className="bg-slate-800 text-white">kr SEK</option>
                      <option value="NOK" className="bg-slate-800 text-white">kr NOK</option>
                      <option value="DKK" className="bg-slate-800 text-white">kr DKK</option>
                    </select>
                  </label>
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Payment Terms</span>
                    <select 
                      name="paymentTerms"
                      className="mt-1 block w-full rounded-md border-white/20 bg-white/10 shadow-sm focus:ring-0 input-focus-glow text-white" 
                      defaultValue="Net 15"
                    >
                      <option value="Due on Receipt" className="bg-slate-800 text-white">Due on Receipt</option>
                      <option value="Net 7" className="bg-slate-800 text-white">Net 7</option>
                      <option value="Net 15" className="bg-slate-800 text-white">Net 15</option>
                      <option value="Net 30" className="bg-slate-800 text-white">Net 30</option>
                      <option value="Net 45" className="bg-slate-800 text-white">Net 45</option>
                      <option value="Net 60" className="bg-slate-800 text-white">Net 60</option>
                    </select>
                  </label>
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Discount (%)</span>
                    <input 
                      name="discountRate"
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      value={discountRate}
                      onChange={(e) => setDiscountRate(parseFloat(e.target.value) || 0)}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                      style={getCustomInputStyles()}
                      placeholder="0.00"
                    />
                  </label>
                  <label className="block">
                    <span className="text-sm font-medium ${getTemplateLabelColor()}">Discount Amount</span>
                    <input 
                      name="discountAmount"
                      type="number"
                      min="0"
                      step="0.01"
                      value={discountAmount}
                      onChange={(e) => setDiscountAmount(parseFloat(e.target.value) || 0)}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                      style={getCustomInputStyles()}
                      placeholder="0.00"
                    />
                  </label>

        </div>
              </section>

              {/* Product Sales Section - Hidden */}
              {false && invoiceType === 'product_sales' && (
                <section className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Line Items</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-5"><span className="text-sm font-medium ${getTemplateLabelColor()}">Item Description</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Quantity</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Price</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Total</span></div>
                    </div>
                    {lineItems.map((item) => (
                      <div key={item.id} className="grid grid-cols-12 gap-4 items-center" data-line-item>
                        <input 
                          name="itemDescription" 
                          className={`col-span-5 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="e.g., iPhone 15 Pro" 
                          type="text"
                          value={item.description}
                          onChange={(e) => updateLineItem(item.id, 'description', e.target.value)}
                        />
                        <input 
                          name="quantity" 
                          className={`col-span-2 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="1" 
                          type="number" 
                          value={item.quantity}
                          onChange={(e) => updateLineItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                        />
                        <input 
                          name="rate" 
                          className={`col-span-2 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Rate" 
                          type="number" 
                          value={item.rate}
                          onChange={(e) => updateLineItem(item.id, 'rate', parseFloat(e.target.value) || 0)}
                        />
                        <span className="col-span-2 text-sm text-white" data-line-total>${item.amount.toFixed(2)}</span>
                        <button 
                          type="button" 
                          onClick={() => removeLineItem(item.id)} 
                          className="col-span-1 text-white/60 hover:text-red-400 transition-transform duration-200 hover:scale-110"
                        >
                          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path clipRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" fillRule="evenodd"></path>
                          </svg>
                        </button>
                      </div>
                    ))}
                    <button type="button" onClick={addLineItem} className="text-sm font-medium text-[var(--primary-color)] hover:text-blue-300 transition-transform duration-200 hover:scale-105">+ Add Line Item</button>
                  </div>
                </section>
              )}

              {/* Freelance Consulting Section */}
              {invoiceType === 'freelance_consulting' && (
                <section className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Services</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-5"><span className="text-sm font-medium ${getTemplateLabelColor()}">Service Description</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Hours</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Rate</span></div>
                      <div className="col-span-2"><span className="text-sm font-medium ${getTemplateLabelColor()}">Total</span></div>
                    </div>
                    {lineItems.map((item) => (
                      <div key={item.id} className="grid grid-cols-12 gap-4 items-center" data-line-item>
                        <input 
                          name="serviceDescription" 
                          className={`col-span-5 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="e.g., UI/UX Design" 
                          type="text"
                          value={item.description}
                          onChange={(e) => updateLineItem(item.id, 'description', e.target.value)}
                        />
                        <input 
                          name="quantity" 
                          className={`col-span-2 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Qty" 
                          type="number" 
                          value={item.quantity}
                          onChange={(e) => updateLineItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                        />
                        <input 
                          name="rate" 
                          className={`col-span-2 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Rate" 
                          type="number" 
                          value={item.rate}
                          onChange={(e) => updateLineItem(item.id, 'rate', parseFloat(e.target.value) || 0)}
                        />
                        <span className="col-span-2 text-sm text-white" data-line-total>${item.amount.toFixed(2)}</span>
                        <button 
                          type="button" 
                          onClick={() => removeLineItem(item.id)} 
                          className="col-span-1 text-white/60 hover:text-red-400 transition-transform duration-200 hover:scale-110"
                        >
                          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path clipRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" fillRule="evenodd"></path>
                          </svg>
                        </button>
                      </div>
                    ))}
                    <button type="button" onClick={addLineItem} className="text-sm font-medium text-[var(--primary-color)] hover:text-blue-300 transition-transform duration-200 hover:scale-105">+ Add Service</button>
                  </div>
                </section>
              )}

              {/* Time Tracking Section */}
              {invoiceType === 'time_tracking' && (
                <section className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Time Tracking</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Start Time</span>
                        <input className="mt-1 block w-full rounded-md border-white/20 bg-white/10 shadow-sm focus:ring-0 input-focus-glow text-white" type="time"/>
                      </label>
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">End Time</span>
                        <input className="mt-1 block w-full rounded-md border-white/20 bg-white/10 shadow-sm focus:ring-0 input-focus-glow text-white" type="time"/>
                      </label>
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Hourly Rate ($)</span>
                        <input 
                          name="hourlyRate" 
                          className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Hourly rate" 
                          type="number"
                        />
                      </label>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                      <div>
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Total Hours:</span>
                        <span className="ml-2 text-white font-semibold">8.5 hours</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Total Amount:</span>
                        <span className="ml-2 text-white font-semibold">$637.50</span>
                      </div>
                      <button 
                        type="button"
                        onClick={() => {
                          const startTime = (document.querySelector('input[type="time"]') as HTMLInputElement)?.value;
                          const endTime = (document.querySelectorAll('input[type="time"]')[1] as HTMLInputElement)?.value;
                          const hourlyRate = parseFloat((document.querySelector('input[name="hourlyRate"]') as HTMLInputElement)?.value || '0');
                          
                          if (startTime && endTime) {
                            const start = new Date(`2000-01-01T${startTime}`);
                            const end = new Date(`2000-01-01T${endTime}`);
                            const diffMs = end.getTime() - start.getTime();
                            const diffHours = diffMs / (1000 * 60 * 60);
                            const totalAmount = diffHours * hourlyRate;
                            
                            showSuccess(`Hours: ${diffHours.toFixed(2)} | Total: $${totalAmount.toFixed(2)}`);
                          } else {
                            showError('Please enter start time, end time, and hourly rate');
                          }
                        }}
                        className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded border border-white/20 transition-colors"
                      >
                        Calculate
                      </button>
                    </div>
                    <div className="space-y-3">
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Work Description</span>
                        <textarea className="mt-1 block w-full rounded-md shadow-sm focus:ring-0 input-focus-glow ${getTemplateInputClasses()}" placeholder="Describe the work performed..." rows={3}></textarea>
                      </label>
                    </div>
                  </div>
                </section>
              )}

              {/* Simple Receipt Section */}
              {invoiceType === 'simple_receipt' && (
                <section className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Receipt Details</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Description</span>
                        <input 
                          name="itemDescription" 
                          className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Payment for services rendered" 
                          type="text"
                        />
                      </label>
                      <label className="block">
                        <span className="text-sm font-medium ${getTemplateLabelColor()}">Amount</span>
                        <input 
                          name="rate" 
                          className={`mt-1 block w-full rounded-md shadow-sm focus:ring-0 ${getTemplateInputClasses()} ${getInputStyles()}`} 
                          style={getCustomInputStyles()}
                          placeholder="Amount" 
                          type="number"
                        />
                      </label>
                    </div>
                  </div>
                </section>
              )}





            </form>
                  </div>
      </main>


          {/* Pricing Section */}
          <section className="mb-16">
            <div className="max-w-7xl mx-auto px-0 sm:px-1 lg:px-2">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-white mb-4">Choose Your Plan</h2>
                <p className="text-xl text-white/80 max-w-2xl mx-auto">
                  Pay per invoice or subscribe for unlimited access. No hidden fees.
                </p>
              </div>
              
              {/* Pricing Toggle */}
              <div className="flex justify-center mb-8">
                <div className="glass-effect rounded-full p-1 flex">
                  <button 
                    onClick={() => setPricingMode('subscription')}
                    className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                      pricingMode === 'subscription' 
                        ? 'bg-[var(--primary-color)] text-white' 
                        : 'text-white/70 hover:text-white'
                  }`}
                >
                  Monthly
                </button>
                  <button 
                    onClick={() => setPricingMode('per-invoice')}
                    className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                      pricingMode === 'per-invoice' 
                        ? 'bg-[var(--primary-color)] text-white' 
                        : 'text-white/70 hover:text-white'
                  }`}
                >
                  Pay Per Invoice
                </button>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row justify-center gap-6 max-w-4xl mx-auto">
                {/* Pay Per Invoice Plans */}
                {pricingMode === 'per-invoice' ? (
                  <>
                    {/* Basic Per Invoice */}
                    <div className="glass-effect rounded-2xl p-6 relative">
                      <div className="text-center">
                        <h3 className="text-2xl font-bold text-white mb-2">Basic</h3>
                        <div className="mb-4">
                          <span className="text-4xl font-bold text-white">£1.50</span>
                          <span className="text-white/60">/invoice</span>
                        </div>
                        <p className="text-white/70 mb-6">Perfect for occasional use</p>
                        
                        <ul className="space-y-3 mb-8 text-left">
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Basic templates
                          </li>
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            PDF download
                          </li>
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Email support
                        </li>
                      </ul>
                      
                      <button 
                        onClick={async () => {
                          try {
                            showLoading('Processing payment...');
                            const success = await createOneTimePayment(PRICING_PLANS.basic.priceId);
                            if (!success) {
                              showError('Payment failed. Please try again.');
                            }
                          } catch (error) {
                            showError('Payment failed. Please try again.');
                          }
                        }}
                        className="w-full py-3 px-6 bg-white/10 text-white rounded-lg border border-white/20 hover:bg-white/20 transition-colors"
                      >
                        Pay £1.50 per Invoice
                      </button>
                    </div>
                  </div>

                  {/* Premium Per Invoice */}
                  <div className="relative">
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                      <span className="bg-[var(--primary-color)] text-white px-4 py-1 rounded-full text-sm font-medium shadow-lg">
                        Most Popular
                      </span>
                    </div>
                    <div className="glass-effect rounded-2xl p-6 border-2 border-[var(--primary-color)]">
                      <div className="text-center">
                        <h3 className="text-2xl font-bold text-white mb-2">Premium</h3>
                        <div className="mb-4">
                          <span className="text-4xl font-bold text-white">£3.50</span>
                          <span className="text-white/60">/invoice</span>
                        </div>
                        <p className="text-white/70 mb-6">For professional invoices</p>
                        
                        <ul className="space-y-3 mb-8 text-left">
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Premium templates
                          </li>
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Auto-calculation
                          </li>
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Priority support
                          </li>
                          <li className="flex items-center text-white/80">
                            <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Custom branding
                          </li>
                        </ul>
                        
                        <button 
                          onClick={async () => {
                            try {
                              showLoading('Processing payment...');
                              const success = await createOneTimePayment(PRICING_PLANS.premium.priceId);
                              if (!success) {
                                showError('Payment failed. Please try again.');
                              }
                            } catch (error) {
                              showError('Payment failed. Please try again.');
                            }
                          }}
                          className="w-full py-3 px-6 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--primary-color)]/80 transition-colors font-medium"
                        >
                          Pay £3.50 per Invoice
                        </button>
                      </div>
                    </div>
                  </div>

                </>
              ) : (
                <>
                  {/* Free Plan */}
                  <div className="glass-effect rounded-2xl p-6 relative">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold text-white mb-2">Free</h3>
                      <div className="mb-4">
                        <span className="text-4xl font-bold text-white">£0</span>
                        <span className="text-white/60">/month</span>
                      </div>
                      <p className="text-white/70 mb-6">Perfect for getting started</p>
                      
                      <ul className="space-y-3 mb-8 text-left">
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          2 invoices per month
                        </li>
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Basic templates
                        </li>
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          PDF download
                        </li>
                      </ul>
                      
                      <button className="w-full py-3 px-6 bg-white/10 text-white rounded-lg border border-white/20 hover:bg-white/20 transition-colors">
                        Get Started Free
                      </button>
                    </div>
                  </div>

                  {/* Pro Plan */}
                  <div className="relative">
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                      <span className="bg-[var(--primary-color)] text-white px-4 py-1 rounded-full text-sm font-medium shadow-lg">
                        Most Popular
                      </span>
                    </div>
                    <div className="glass-effect rounded-2xl p-6 border-2 border-[var(--primary-color)]">
                      <div className="text-center">
                      <h3 className="text-2xl font-bold text-white mb-2">Pro</h3>
                      <div className="mb-4">
                        <span className="text-4xl font-bold text-white">£12</span>
                        <span className="text-white/60">/month</span>
                      </div>
                      <p className="text-white/70 mb-6">For growing businesses</p>
                      
                      <ul className="space-y-3 mb-8 text-left">
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Unlimited invoices
                        </li>
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          All premium templates
                        </li>
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Auto-calculation
                        </li>
                        <li className="flex items-center text-white/80">
                          <svg className="w-5 h-5 text-green-400 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Priority support
                        </li>
                      </ul>
                      
                      <button 
                        onClick={() => handleStripeCheckout('pro')}
                        className="w-full py-3 px-6 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--primary-color)]/80 transition-colors font-medium"
                      >
                        Start Pro
                      </button>
                      </div>
                    </div>
                  </div>

                </>
              )}
            </div>
          </div>
        </section>

        {/* CTA Section */}

        {/* Newsletter Section */}
        <section className="mt-8 mb-20">
          <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6">
            <div className="relative overflow-hidden text-white rounded-2xl">
              <div className="absolute inset-0 bg-gradient-to-r from-gray-800/40 via-gray-700/30 to-gray-800/40"></div>
              <div className="relative text-center pt-12 pr-8 pb-12 pl-8">
                <h2 className="text-3xl font-serif font-medium mb-4">Join the StitchInvoice Experience</h2>
                <p className="text-lg opacity-90 mb-6 max-w-xl mx-auto">Be the first to discover new features, exclusive templates, and member-only benefits.</p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-4">
                  <input 
                    type="email" 
                    placeholder="Enter your email" 
                    className="px-4 py-3 rounded-full bg-white/3 backdrop-blur-sm border border-white/8 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-white/15 w-64"
                  />
                  <button 
                    onClick={() => {
                      showSuccess('Thank you for subscribing!');
                    }}
                    className="px-6 py-3 bg-white text-black rounded-full font-medium hover:bg-neutral-100 transition-colors cursor-pointer"
                  >
                    Subscribe
                  </button>
        </div>
                <p className="text-xs opacity-70">No spam, just curated content and exclusive access.</p>
              </div>
            </div>
          </div>
        </section>

      {/* Footer */}
        <footer className="mt-auto py-6 sm:py-8 px-2 sm:px-4 lg:px-6 relative">
          <div className="container mx-auto text-center text-sm text-white/60">
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-3 sm:space-y-0 sm:space-x-4 lg:space-x-6">
              <a className="hover:text-white transition-colors text-xs sm:text-sm" href="/about">About Us</a>
              <a className="hover:text-white transition-colors text-xs sm:text-sm" href="/terms">Terms of Service</a>
              <a className="hover:text-white transition-colors text-xs sm:text-sm" href="/privacy">Privacy Policy</a>
              <a className="hover:text-white transition-colors text-xs sm:text-sm" href="/contacts">Contact Us</a>
            </div>
            <p className="mt-3 sm:mt-4 text-xs sm:text-sm">© 2025 StitchInvoice. All rights reserved.</p>
          </div>
          
          {/* Share Button Bubble */}
          <button 
            onClick={() => {
              if (typeof window !== 'undefined' && navigator.share) {
                navigator.share({
                  title: 'StitchInvoice - Professional Invoice Generator',
                  text: 'Create beautiful, professional invoices in seconds!',
                  url: window.location.origin
                });
              } else if (typeof window !== 'undefined') {
                navigator.clipboard.writeText(window.location.origin);
                showSuccess('Link copied! Share StitchInvoice with others');
              }
            }}
            className="absolute bottom-4 right-4 w-12 h-12 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 hover:bg-white/20"
            title="Share StitchInvoice"
          >
            <span className="material-symbols-outlined text-white text-lg">share</span>
          </button>
      </footer>
      </div>

      {/* Reset Modal */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-30">
          <div className="glass-effect rounded-2xl shadow-lg p-6 w-full max-w-md text-center mx-4">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-500/20">
              <svg className="h-6 w-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path>
              </svg>
            </div>
            <h3 className="mt-5 text-lg font-semibold text-white">Reset Form</h3>
            <p className="mt-2 text-sm text-white/70">Are you sure you want to clear all fields? This action cannot be undone.</p>
            <div className="mt-8 flex justify-center gap-4">
              <button 
                onClick={() => setShowResetModal(false)} 
                className="w-full rounded-lg bg-transparent px-6 py-2.5 text-sm font-bold text-white/70 sm:w-auto btn-hover-effect hover:bg-white/10 border border-white/20"
              >
                Cancel
              </button>
              <button 
                onClick={handleReset} 
                className="w-full rounded-lg bg-red-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg sm:w-auto btn-hover-effect hover:bg-red-700"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Customization Modal */}
      {showCustomizationModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border-2 border-gray-600">
            <div className="p-6 bg-gray-900">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Template Customization</h2>
                <button
                  onClick={() => setShowCustomizationModal(false)}
                  className="text-gray-300 hover:text-white"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Company Information */}
              <div className="mb-8 p-6 bg-gray-800 rounded-lg border border-gray-600">
                <h3 className="text-lg font-semibold text-white mb-4">Company Information</h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Company Name</label>
                        <input
                          type="text"
                      value={currentTemplateState.companyName}
                      onChange={(e) => updateTemplateState({ companyName: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        />
                      </div>
                      <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                    <input
                      type="email"
                      value={currentTemplateState.companyEmail}
                      onChange={(e) => updateTemplateState({ companyEmail: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                          <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Phone</label>
                              <input
                      type="text"
                      value={currentTemplateState.companyPhone}
                      onChange={(e) => updateTemplateState({ companyPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Address</label>
                              <input
                                type="text"
                      value={currentTemplateState.companyAddress}
                      onChange={(e) => updateTemplateState({ companyAddress: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                              />
                            </div>
                          </div>
              </div>

              {/* Client Information */}
              <div className="mb-8 p-6 bg-gray-800 rounded-lg border border-gray-600">
                <h3 className="text-lg font-semibold text-white mb-4">Client Information</h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                          <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Client Name</label>
                              <input
                      type="text"
                      value={currentTemplateState.clientName}
                      onChange={(e) => updateTemplateState({ clientName: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Client Email</label>
                              <input
                      type="email"
                      value={currentTemplateState.clientEmail}
                      onChange={(e) => updateTemplateState({ clientEmail: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                          </div>
                          <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Client Phone</label>
                              <input
                      type="text"
                      value={currentTemplateState.clientPhone}
                      onChange={(e) => updateTemplateState({ clientPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Client Address</label>
                              <input
                                type="text"
                      value={currentTemplateState.clientAddress}
                      onChange={(e) => updateTemplateState({ clientAddress: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                          </div>
                        </div>
                      </div>

              {/* Invoice Items */}
              <div className="mb-8 p-6 bg-gray-800 rounded-lg border border-gray-600">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-white">Invoice Items</h3>
                  <button
                    onClick={() => {
                      const newItem = {
                        id: Date.now(),
                        description: '',
                        quantity: 1,
                        rate: 0,
                        amount: 0
                      };
                      updateTemplateState({ 
                        items: [...currentTemplateState.items, newItem] 
                      });
                    }}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium"
                  >
                    + Add Item
                  </button>
                        </div>
                <div className="space-y-4">
                  {currentTemplateState.items.map((item) => (
                    <div key={item.id} className="p-4 bg-gray-700 rounded-lg border-2 border-gray-500 shadow-sm">
                      <div className="grid grid-cols-1 gap-4">
                      <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) => {
                              const updatedItems = currentTemplateState.items.map(i => 
                                i.id === item.id ? { ...i, description: e.target.value } : i
                              );
                              updateTemplateState({ items: updatedItems });
                            }}
                            className="w-full px-3 py-2 bg-gray-600 border border-gray-400 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                      </div>
                        <div className="grid grid-cols-2 gap-4">
                      <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Quantity</label>
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => {
                                const quantity = parseFloat(e.target.value) || 0;
                                const amount = quantity * item.rate;
                                const updatedItems = currentTemplateState.items.map(i => 
                                  i.id === item.id ? { ...i, quantity, amount } : i
                                );
                                updateTemplateState({ items: updatedItems });
                              }}
                              className="w-full px-3 py-2 bg-gray-600 border border-gray-400 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                            />
                      </div>
                      <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Rate</label>
                            <input
                              type="number"
                              value={item.rate}
                              onChange={(e) => {
                                const rate = parseFloat(e.target.value) || 0;
                                const amount = item.quantity * rate;
                                const updatedItems = currentTemplateState.items.map(i => 
                                  i.id === item.id ? { ...i, rate, amount } : i
                                );
                                updateTemplateState({ items: updatedItems });
                              }}
                              className="w-full px-3 py-2 bg-gray-600 border border-gray-400 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                            />
                      </div>
                    </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">Amount</label>
                          <input
                            type="number"
                            value={item.amount}
                            readOnly
                            className="w-full px-3 py-2 border border-gray-400 rounded-md bg-gray-500 text-white"
                          />
                        </div>
                            <button
                          onClick={() => {
                            const updatedItems = currentTemplateState.items.filter(i => i.id !== item.id);
                            updateTemplateState({ items: updatedItems });
                          }}
                          className="text-red-400 hover:text-red-300 text-sm"
                        >
                          Remove Item
                            </button>
                        </div>
                      </div>
                  ))}
                    </div>
                  </div>

              {/* Visual Element Toggles */}
              <div className="mb-8 p-6 bg-gray-800 rounded-lg border border-gray-600">
                <h3 className="text-lg font-semibold text-white mb-4">Show/Hide Elements</h3>
                    <div className="grid grid-cols-2 gap-4">
                  <label className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                      checked={currentTemplateState.logoVisible}
                      onChange={() => toggleElement('logoVisible')}
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <span className="text-gray-300">Show Logo</span>
                          </label>
                  
                  <label className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                      checked={currentTemplateState.thankYouNoteVisible}
                      onChange={() => toggleElement('thankYouNoteVisible')}
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <span className="text-gray-300">Show Thank You Note</span>
                          </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={currentTemplateState.termsAndConditionsVisible}
                      onChange={() => toggleElement('termsAndConditionsVisible')}
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <span className="text-gray-300">Show Terms & Conditions</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={currentTemplateState.signatureVisible}
                      onChange={() => toggleElement('signatureVisible')}
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                    />
                    <span className="text-gray-300">Show Signature</span>
                  </label>
                      </div>
                    </div>

              {/* Styling Options */}
              <div className="mb-8 p-6 bg-gray-800 rounded-lg border border-gray-600">
                <h3 className="text-lg font-semibold text-white mb-4">Styling Options</h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Primary Color</label>
                    <input
                      type="text"
                      value={currentTemplateState.primaryColor}
                      onChange={(e) => updateTemplateState({ primaryColor: e.target.value })}
                      placeholder="#7C3AED"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                            <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Secondary Color</label>
                    <input
                      type="text"
                      value={currentTemplateState.secondaryColor}
                      onChange={(e) => updateTemplateState({ secondaryColor: e.target.value })}
                      placeholder="#8B5CF6"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Font Family</label>
                    <select
                      value={currentTemplateState.fontFamily}
                      onChange={(e) => updateTemplateState({ fontFamily: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="Inter">Inter</option>
                      <option value="Roboto">Roboto</option>
                      <option value="Open Sans">Open Sans</option>
                      <option value="Lato">Lato</option>
                      <option value="Montserrat">Montserrat</option>
                      <option value="Poppins">Poppins</option>
                    </select>
                        </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Layout Style</label>
                    <select
                      value={currentTemplateState.layout}
                      onChange={(e) => updateTemplateState({ layout: e.target.value as "minimal" | "modern" | "standard" | "detailed" })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="standard">Standard</option>
                      <option value="minimal">Minimal</option>
                      <option value="detailed">Detailed</option>
                      <option value="modern">Modern</option>
                    </select>
                        </div>
                            <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Table Style</label>
                    <select
                      value={currentTemplateState.tableStyle}
                      onChange={(e) => updateTemplateState({ tableStyle: e.target.value as "minimal" | "bordered" | "striped" | "modern" })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="bordered">Bordered</option>
                      <option value="striped">Striped</option>
                      <option value="minimal">Minimal</option>
                      <option value="modern">Modern</option>
                    </select>
                            </div>
                            <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Corner Radius</label>
                    <select
                      value={currentTemplateState.cornerRadius}
                      onChange={(e) => updateTemplateState({ cornerRadius: e.target.value as "small" | "none" | "medium" | "large" })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-500 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="none">None</option>
                      <option value="small">Small</option>
                      <option value="medium">Medium</option>
                      <option value="large">Large</option>
                    </select>
                            </div>
                        </div>
                          </div>

              {/* Close Button */}
              <div className="flex justify-end">
                  <button
                  onClick={() => setShowCustomizationModal(false)}
                  className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Done
                  </button>
                        </div>
                          </div>
                          </div>
                          </div>
                        )}
                        
      {/* Floating Calculator */}
      <FloatingCalculator />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
      />

      {/* Legacy Custom Builder Modal removed - now using unified TemplateManager */}

      {/* Guest Limit Modal */}
      {showGuestLimitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 w-full max-w-md">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-yellow-400/30">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.268 19.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">Guest Limit Reached</h3>
              <p className="text-white/70 mb-6">
                You've created {GUEST_INVOICE_LIMIT} invoices as a guest. Sign up for free to create unlimited invoices and access premium features!
              </p>
              
              <div className="space-y-3">
                  <button
                    onClick={() => {
                    setAuthMode('signup');
                    setAuthModalOpen(true);
                    setShowGuestLimitModal(false);
                  }}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 shadow-lg hover:shadow-blue-500/25 transform hover:scale-[1.02]"
                >
                  Sign Up for Free
                  </button>
                
                  <button
                  onClick={() => setShowGuestLimitModal(false)}
                  className="w-full bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 border border-white/20 hover:border-white/30"
                  >
                  Continue as Guest
                  </button>
                </div>
              
              <div className="mt-4 text-center">
                <p className="text-white/50 text-sm">
                  Free accounts get 3 invoices/month, Pro accounts get unlimited!
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Gate Modal */}
      <PaymentGateModal
        isOpen={showPaymentGate}
        onClose={() => setShowPaymentGate(false)}
        onPaymentSuccess={handlePaymentSuccess}
        isGuest={paymentGateStatus.isGuest}
        remainingFreeInvoices={paymentGateStatus.remainingFreeInvoices}
      />
    </div>
  );
}